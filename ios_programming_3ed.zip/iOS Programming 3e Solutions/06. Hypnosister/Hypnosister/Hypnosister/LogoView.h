//
//  LogoView.h
//  Hypnosister
//
//  Created by joeconway on 8/24/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LogoView : UIView

@end
