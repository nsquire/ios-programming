//
//  BNRAppDelegate.h
//  Blocky
//
//  Created by joeconway on 12/21/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BNRExecutor.h"

@interface BNRAppDelegate : UIResponder <UIApplicationDelegate>
{
}

@property (strong, nonatomic) UIWindow *window;

@end
