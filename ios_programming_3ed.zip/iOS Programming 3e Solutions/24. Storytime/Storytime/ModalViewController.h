//
//  ModalViewController.h
//  Storytime
//
//  Created by joeconway on 1/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalViewController : UIViewController
- (IBAction)dismiss:(id)sender;
@end
