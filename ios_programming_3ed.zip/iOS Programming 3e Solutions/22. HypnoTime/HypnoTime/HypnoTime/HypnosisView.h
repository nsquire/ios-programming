//
//  HypnosisView.h
//  Hypnosister
//
//  Created by joeconway on 8/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface HypnosisView : UIView
{
    CALayer *boxLayer;
}
@property (nonatomic, strong) UIColor *circleColor;
@end
